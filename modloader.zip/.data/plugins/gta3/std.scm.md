gta3.std.scm
=========================================================================
 + __Author__:   LINK/2012 (<dma_2012@hotmail.com>)
 + __Priority__: 50
 + __Game__: III, Vice City, San Andreas

*************************************************************************

__Description__:
 This plugin is responsible for handling the non-streamed script file main.scm

